<?php 

class Student extends MY_Controller
{
    public function __construct()
    {
        parent::__construct();

        // loading the users model
        $this->load->model('model_users');
        $this->load->model('model_student');

        // loading the form validation library
        $this->load->library('form_validation');

    }
	public function index($page = 'home')
	{

        $data['title'] = "";

        $this->StudentIsNotLoggedIn();

        $this->load->view('site_template/header', $data);
        $this->load->view("studentLogin", $data);
        $this->load->view('site_template/footer', $data);
	}

    public function login()
    {

        $validator = array('success' => false, 'messages' => array());

        $validate_data = array(
            array(
                'field' => 'userEmail',
                'label' => 'userEmail',
                'rules' => 'required|callback_validate_username'
            ),
            array(
                'field' => 'userPassword',
                'label' => 'userPassword',
                'rules' => 'required'
            )
        );

        $this->form_validation->set_rules($validate_data);
        $this->form_validation->set_error_delimiters('<p class="text-danger">','</p>');

        if($this->form_validation->run() === true) {
            $username = $this->input->post('userEmail');
            $password = md5($this->input->post('userPassword'));

            $login = $this->model_student->Studentlogin($username, $password);

            if($login) {
                $this->load->library('session');

                $user_data = array(
                    'student_id' => $login,
                    'logged_in' => true,
                    'member_type' => "student"
                );

                $this->session->set_userdata($user_data);

                $validator['success'] = true;
                $validator['messages'] = "admin/dashboard";
                $this->StudentIsNotLoggedIn();
                $data['title'] = "Student Dashboard";
                $this->load->view('site_template/header', $data);
                $this->load->view("studentDashBoard", $data);
                $this->load->view('site_template/footer', $data);
               // exit();
            }
            else {
                $validator['success'] = false;
                $validator['messages'] = "Incorrect username/password combination";
            } // /else

        }
        else {
            redirect('', 'refresh');
        } // /else


    }

    public function dashboard(){
        $this->StudentIsNotLoggedIn();
        $data['title'] = "Student Dashboard";
        $this->load->view('site_template/header', $data);
        $this->load->view("studentDashBoard", $data);
        $this->load->view('site_template/footer', $data);
    }

    public function validate_username()
    {
        $validate = $this->model_student->validate_current_student_password($this->input->post('userPassword'),$this->input->post('userEmail'));

        if($validate === true) {
            return true;
        }
        else {
            $this->form_validation->set_message('validate_username', 'The {field} does not exists');
            return false;
        } // /else
    } // /validate username function
    
}