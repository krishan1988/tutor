
<!-- Menu -->
<div class="border-bottom">
    <div class="d-flex flex-column flex-md-row align-items-center px-md-4">
        <!-- logo -->
        <a class="tut-logo mr-10"><img src="<?php echo base_url(); ?>assets/front_site_assets/images/logo.svg"/></a>
        <!-- search -->
        <div class="search-con my-0 mr-md-auto font-weight-normal">
            <div class="input-group">
                <span class="search-icon">
                     <img src="<?php echo base_url(); ?>assets/front_site_assets/images/icon/magnifying-glass.svg" width="10%"/>
                </span>
                <input class="form-search form-control-dark" type="text" placeholder="Search" aria-label="Search">
            </div>
        </div>
        <!-- menu -->
        <nav class="my-2 my-md-0 mr-md-3">
            <a class="p-3 text-dark" href="#"><img src="<?php echo base_url(); ?>assets/front_site_assets/images/icon/our-courses.svg"> Course</a>
            <a class="p-3 text-dark" href="#"><img src="<?php echo base_url(); ?>assets/front_site_assets/images/icon/reso.svg"> Resource</a>
            <a class="p-2 text-dark" href="#"><img src="<?php echo base_url(); ?>assets/front_site_assets/images/icon/news.svg"> News</a>
        </nav>
        <a class="btn-signin" href="#" data-toggle="modal" data-target="#myModal">Sign in</a>

        <!-- Modal -->
        <div id="myModal" class="modal fade" role="dialog">
            <div class="modal-dialog">

                <!-- Modal content-->
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title">Login</h4>
                        <button type="button" class="close" data-dismiss="modal">&times;</button>
                    </div>
                    <div class="modal-body">

                        <p>
                            <a href="<?php echo $googleLogin; ?>" class="btn btn-block btn-outline-info"> <i class="fab fa-gmail"></i>   Login via gmail</a>
                            <a href="" class="btn btn-block btn-outline-primary"> <i class="fab fa-facebook-f"></i>   Login via facebook</a>
                        </p>
                        <hr>
                        <form class="form-signin" method="post" action="<?php echo base_url();?>student/login">
                            <div class="form-group">
                                <input name="userEmail"  class="form-control" placeholder="Email or login" type="email">
                            </div> <!-- form-group// -->
                            <div class="form-group">
                                <input class="form-control" name="userPassword" placeholder="******" type="password">
                            </div> <!-- form-group// -->
                            <div class="row">
                                <div class="col-md-6 text-left">
                                    <a class="small" href="#">Forgot password?</a>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <button type="submit" class="btn btn-primary btn-block"> Login  </button>
                                    </div> <!-- form-group// -->
                                </div>
                            </div> <!-- .row// -->
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    </div>
                </div>

            </div>
        </div>

    </div>
</div>



<!-- Main banner -->
<div class="position-relative d-flex main-banner overflow-hidden p-3 m-md-3">

    <div class="col-4 banner-text">
        <h1 class="display-4 font-weight-normal">Build your skill</h1>
        <span>LEARN| TEACH | SHARPEN</span>
        <p class="lead font-weight-normal">Learn new skills, pursue your interests, advance
            your career</p>
        <a class="btn btn-primary join-now" href="#">Join Now</a>
    </div>
    <div class="col-8 main-image p-0">
        <div class="play-video pointer">
            <h3>Play Video <img src="<?php echo base_url(); ?>assets/front_site_assets/images/icon/play-button.svg"></h3>
        </div>
        <img src="<?php echo base_url(); ?>assets/front_site_assets/images/main-image.png">
    </div>


</div>

<!-- angle div -->
<div class="section-one">
    <div class="d-flex">
        <div class="col-6 your-teacher">
            <h1>Your teaching partner</h1>
            <p>We have highly qualified , carefully selected panel of tutors. <br/>You can search subject wise and we will continue to enlist more and more qualified tutors. </p>
        </div>
        <div class="col-6">
            <div class="video-item">
                <div class="v-item">
                    <div class="video">
                        <img src="<?php echo base_url(); ?>assets/front_site_assets/images/video-2.jpg"/>
                    </div>
                    <div class="video-content">
                        Ajax with PHP
                    </div>
                    <div class="rating">
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <span>4.8 views (1300)</span>
                    </div>
                </div>
                <div class="v-item">
                    <div class="video">
                        <img src="<?php echo base_url(); ?>assets/front_site_assets/images/video-2.jpg"/>
                    </div>
                    <div class="video-content">
                        Lorem ipsum dolor sit amet.
                    </div>
                    <div class="rating">
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <span>4.8 views (1300)</span>
                    </div>
                </div>
                <div class="v-item">
                    <div class="video">
                        <img src="<?php echo base_url(); ?>assets/front_site_assets/images/video-3.jpg"/>
                    </div>
                    <div class="video-content">
                        Lorem ipsum dolor sit amet.
                    </div>
                    <div class="rating">
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <span>4.8 views (1300)</span>
                    </div>
                </div>
                <div class="v-item">
                    <div class="video">
                        <img src="<?php echo base_url(); ?>assets/front_site_assets/images/video-4.jpg"/>
                    </div>
                    <div class="video-content">
                        Lorem ipsum dolor sit amet.
                    </div>
                    <div class="rating">
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <svg class="lnr lnr-star"><use xlink:href="#lnr-star"></use></svg>
                        <span>4.8 views (1300)</span>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- tommorow -->
<div class="d-flex section-two mb-10">
    <div class="col-6 pl-0 img-section">
        <img src="<?php echo base_url(); ?>assets/front_site_assets/images/img1.jpg">
    </div>
    <div class="col-6 p-0 pt-50">
        <span>Inspire your class</span>
        <h1 class="pb-30">For today, <br/>tomorrow and every day</h1>

        <div class="d-flex col-12 p-0">
            <div class="col-6 inspire-video pl-0">
                <div class="data-con">
                    <div class="user-item">
                        <div class="video">
                            <img src="<?php echo base_url(); ?>assets/front_site_assets/images/video-3.jpg"/>
                        </div>
                        <div class="video-content">
                            Responsive Layout
                        </div>
                        <div class="view-ppl">
                            <svg class="lnr lnr-user"><use xlink:href="#lnr-user"></use></svg>
                            8,794 viewers
                        </div>
                        <div class="user-user">
                            <img src="<?php echo base_url(); ?>assets/front_site_assets/images/user-1.png">
                            <div class="user-detail-container">
                                <h5>Justin Yost</h5>
                                <span>Lead Engineer at Wirecutter View </span>
                            </div>
                        </div>
                        <div class="details-ppl">
                            During the last few years, After Effects has grown from a simple software program into an ever-evolving motion graphics ecosystem.
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-6 inspire-video">
                <div class="data-con">
                    <div class="user-item">
                        <div class="video">
                            <img src="<?php echo base_url(); ?>assets/front_site_assets/images/video-3.jpg"/>
                        </div>
                        <div class="video-content">
                            Responsive Layout
                        </div>
                        <div class="view-ppl">
                            <svg class="lnr lnr-user"><use xlink:href="#lnr-user"></use></svg>
                            8,794 viewers
                        </div>
                        <div class="user-user">
                            <img src="<?php echo base_url(); ?>assets/front_site_assets/images/user-1.png">
                            <div class="user-detail-container">
                                <h5>Justin Yost</h5>
                                <span>Lead Engineer at Wirecutter View </span>
                            </div>
                        </div>
                        <div class="details-ppl">
                            During the last few years, After Effects has grown from a simple software program into an ever-evolving motion graphics ecosystem.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- online coruse catagory -->
<section class="content-section mt-50 mb-50">
    <div class="container text-center">
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <h1>Browse online course categories</h1>
                <p class="lead mb-5">Online learning offers a new way to explore subjects you’re passionate about. Find your interests by browsing our online course categories:</p>
            </div>
        </div>
    </div>
</section>

<section class="teaching-con">
    <div class="container text-center">
        <div class="row">
            <div class="col-lg-10 mx-auto">
                <h1 class="pb-0 mb-5">Tutor for teaching</h1>
                <p class="lead mb-30">Come on in and join the biggest community of educators in the world</p>
                <a class="btn btn-primary join-now" href="#">Free Join Now</a>
            </div>
        </div>
    </div>
</section>

<footer>

</footer>
<!-- Optional JavaScript -->
<!-- jQuery first, then Popper.js, then Bootstrap JS -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.0/umd/popper.min.js" integrity="sha384-cs/chFZiN24E4KMATLdqdvsezGxaGsi4hLGOzlXwp5UZB1LY//20VyM2taTB4QvJ" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.0/js/bootstrap.min.js" integrity="sha384-uefMccjFJAIv6A+rW+L4AHf99KvxDjWSu1z9VI8SKNVmz4sk7buKt/6v9KI65qnm" crossorigin="anonymous"></script>

</body>
</html>